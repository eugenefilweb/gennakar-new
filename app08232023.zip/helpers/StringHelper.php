<?php

namespace app\helpers;

class StringHelper extends \yii\helpers\StringHelper
{
}